package dominos;

import java.util.Scanner;
import java.util.Random;
import java.util.ArrayList;

public class Dominos {

    public static String[][] dominoSet = new String[7][7];
    public static String[][] setHands = new String[7][7];

    public static ArrayList<String> player1 = new ArrayList();
    public static ArrayList<String> player2 = new ArrayList();

    public static ArrayList<String> Boneyard = new ArrayList();
    public static ArrayList<String> Game = new ArrayList();

    public static boolean playerOneTurn;
    public static boolean firstTurn = true;

    public static String playerOne;
    public static String playerTwo;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
try{
        System.out.println("Welcome to dominos...\nThe rules are simple, first one to have an empty hand wins...\nOr if the boneyard runs dry then the player with the smallest hand wins\n");
        System.out.println("Enter name of Player 1: ");
        playerOne = scanner.next();
        System.out.println("Enter the name of Player 2: ");
        playerTwo = scanner.next();
        setTiles();
        setHands();
        printHands();

        String Double1 = findHighest(player1);
        System.out.println("\n"+ playerOne + " Double:" + Double1);
        String Double2 = findHighest(player2);
        System.out.println(playerTwo + " Double:" + Double2);
        if (Double1.equals("No") && Double2.equals("No")) {
            setTiles();
            setHands();
            printHands();
        }
        if (Double1.equals("No") == false && Double2.equals("No")) {
            System.out.println(playerOne + " starts...");
            playerOneTurn = true;
        }
        if (Double1.equals("No") && Double2.equals("No") == false) {
            System.out.println(playerTwo + " starts...");
            playerOneTurn = false;
        }

        if (Integer.parseInt(Double1.substring(2)) > Integer.parseInt(Double2.substring(2))) {
            System.out.println(playerOne + " starts...");
            playerOneTurn = true;
        } else {
            System.out.println(playerTwo + " starts...");
            playerOneTurn = false;
        }
}catch(Exception e){
    System.out.println(e);
            setTiles();
            setHands();
            printHands();
            
        String Double1 = findHighest(player1);
        System.out.println("\n"+ playerOne + " Double:" + Double1);
        String Double2 = findHighest(player2);
        System.out.println(playerTwo + " Double:" + Double2);
            
            choice();
}
        choice();

    }

    public static void setTiles() {
        int decrease = 6;

        for (int j = 6; j >= 0; j--) {
            for (int k = decrease; k >= 0; k--) {
                dominoSet[j][k] = j + ":" + k;
                System.out.println(dominoSet[j][k]);
                setHands[j][k] = "F";
            }
            decrease -= 1;
        }

    }

    public static void setHands() {
        Random rand = new Random();
        int random = rand.nextInt(7);
        int random2 = rand.nextInt(7);

        for (int i = 0; i < 7; i++) {
            while (setHands[random][random2] != "F") {
                random = rand.nextInt(7);
                random2 = rand.nextInt(7);
            }
            setHands[random][random2] = "T";
            player1.add(dominoSet[random][random2]);

        }

        for (int i = 0; i < 7; i++) {

            while (setHands[random][random2] != "F") {
                random = rand.nextInt(7);
                random2 = rand.nextInt(7);
            }
            setHands[random][random2] = "T";
            player2.add(dominoSet[random][random2]);

        }
    }

    public static void printHands() {
        System.out.println("\nPlayer1:");
        for (int i = 0; i < player1.size(); i++) {
            System.out.println(player1.get(i));
        }
        System.out.println("\nPlayer2:");
        for (int i = 0; i < player1.size(); i++) {
            System.out.println(player2.get(i));
        }

        System.out.println("\nBoneYard:");
        for (int i = 0; i < 7; i++) {
            for (int j = 0; j < 7; j++) {
                if (setHands[i][j] == "F") {
                    Boneyard.add(dominoSet[i][j]);
                }
            }
        }
        for (int i = 0; i < Boneyard.size(); i++) {
            System.out.println(Boneyard.get(i));
        }
    }

    public static String findHighest(ArrayList<String> list) {
        String Domino = "";
        String HighestDouble = "No";
        int highest = -1;

        for (int i = 0; i < list.size(); i++) {
            Domino = list.get(i);
            int num1 = Domino.charAt(0);
            int num2 = Domino.charAt(2);

            if (num1 == num2 && num1 > highest) {
                highest = num1;
                HighestDouble = list.get(i);
            }
        }

        return HighestDouble;
    }

    public static void printBoard(){
    System.out.println("Board");
        System.out.println("-----");
        for (int i = 0; i < Game.size(); i++) {
            System.out.print("  " + "[ " + Game.get(i) + " ]");
        }
    }
    
    
    public static void choice() {

        printBoard();

        if (player1.isEmpty()) {
            System.out.println("\n" + playerOne + " is the winner !!");
            System.exit(0);
        }
        if (player2.isEmpty()) {
            System.out.println("\n" + playerTwo + "is the winner !!");
            System.exit(0);
        }

        Scanner input = new Scanner(System.in);
        System.out.println("");
        if (playerOneTurn == true) {
            playerOneTurn = false;
            printList(player1);
            System.out.println(playerOne + " play or pass ?");
            String Choice = input.next();
            if (Choice.equals("play")) {
                play(player1);
            } else {
                if (Choice.equals("pass")) {
                    pass(player1);
                }else{
                    System.out.println("That's not a valid input...");
                    playerOneTurn = true;
                    choice();
                }
            }

        } else {
            playerOneTurn = true;
            printList(player2);
            System.out.println(playerTwo + " play or pass ?");
            String Choice = input.next();
            if (Choice.equals("play")) {
                play(player2);
            } else {
                if (Choice.equals("pass")) {
                    pass(player2);
                }else{
                    System.out.println("That's not a valid input...");
                    playerOneTurn = false;
                    choice();
                }
            }
        }
    }

    public static void pass(ArrayList list) {
        
        
        Random rand = new Random();
        int val = rand.nextInt(Boneyard.size());

        if(Boneyard.size() == 1)
        {
            System.out.println("Boneyard is dry");
            if(player1.size() > player2.size()){
                System.out.println(playerTwo + " is the Winner - With the smallest hand ");
                System.exit(0);
            }else{
                System.out.println(playerOne + " is the Winner - With the smallest hand");
                System.exit(0);
            }

        }
        list.add(Boneyard.get(val));
        Boneyard.remove(val);
        choice();
        
        
        
    }

    public static void play(ArrayList<String> list) {
        Scanner input = new Scanner(System.in);

        if (firstTurn == true) {
            firstTurn = false;
            System.out.println("Which domino would you like to play ?");
            int Domino = input.nextInt();
            while (Domino > list.size() || Domino < 0) {
                System.out.println("Re-enter valid domino");
                Domino = input.nextInt();
            }
            Game.add(list.get(Domino));
            String compare = list.get(Domino);
            list.remove(Domino);
            int num1 = compare.charAt(0);
            int num2 = compare.charAt(2);

            if (num1 == num2) {
                System.out.println("It's a double, you get another turn");
                System.out.println("Or would you like to pass ?");
                String pass = input.next();
                if (pass.equals("yes") || pass.equals("pass")) {
                    choice();
                } else {
                    printBoard();
                    System.out.println("");
                    printList(list);
                    play(list);
                }

            }
            choice();
        } else {
            try{
            //Main
            System.out.println("Which domino would you like to play ?");
            int Domino = input.nextInt();
            while (Domino > list.size() || Domino < 0) {
                System.out.println("Re-enter valid domino");
                Domino = input.nextInt();
            }
            String compare = list.get(Domino);
            int num1 = compare.charAt(0);
            int num2 = compare.charAt(2);

            String pieceBefore = Game.get(Game.size() - 1);
            int numBefore = pieceBefore.charAt(2);
            
            String compareReflect = new StringBuilder(compare).reverse().toString();
            
            if (numBefore == num1) {                        //need to reverse the string also
                Game.add(compare);
            } else if(numBefore == num2){
            Game.add(compareReflect);
            } else {
                System.out.println("That piece can not be played...");
                System.out.println("Can you play a domino ?");
                String unable = input.next();
                if(unable.equals("no") || unable.equals("pass"))
                {
                    System.out.println("PASSING");
                pass(list);
                }
                printBoard();
                play(list);
            }

            if (num1 == num2) {
                if(list.isEmpty()){
                choice();                
                }
                System.out.println("It's a double, you get another turn");
                list.remove(Domino);
                System.out.println("Or would you like to pass ?");
                String pass = input.next();
                if (pass.equals("yes") || pass.equals("pass")) {
                    choice();
                } else {
                    printBoard();
                    printList(list);
                    play(list);
                }
            }
            list.remove(Domino);
            choice();
            
            }catch(Exception e){
                System.out.println("Gussing you can't play huh");
                choice();
            }
        }

    }

    public static void printList(ArrayList list) {
        for (int i = 0; i < list.size(); i++) {
            System.out.println(i + " = " + list.get(i));
        }
    }

}
